# avdweb_FreqPeriodCounter
Smart library with comprehensive functions for counting (multiple) frequencies and period-times. For Arduino Uno and Zero.
http://www.avdweb.nl/arduino/libraries/frequency-period-counter.html
